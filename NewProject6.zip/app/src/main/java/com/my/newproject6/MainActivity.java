package com.my.newproject6;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;



public class MainActivity extends Activity {

	private LinearLayout linear1;
	private WebView webview1;
	private Spinner spinner1;
	private ImageView imageview1;
	private ImageView imageview3;
	private ImageView imageview5;
	private ImageView imageview6;
	private ImageView imageview2;
	private ImageView imageview7;
	private ImageView imageview4;
	private ImageView imageview8;
	private ImageView imageview9;
	private ImageView imageview11;
	private ImageView imageview10;

	private double s1 = 0;
	private double s2 = 0;
	private double s3 = 0;
	private double s4 = 0;
	private double s5 = 0;
	private double s6 = 0;
	private double listg = 0;

	private ArrayList<String> list = new ArrayList<String>();

	private SoundPool sound;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _view,final String _url, Bitmap _favicon) {
				showMessage("wait page loading 30 sec.........");
				super.onPageStarted(_view, _url, _favicon);
			}
			@Override
			public void onPageFinished(WebView _view,final String _url) {
				showMessage("loaded");
				webview1.zoomOut();
				super.onPageFinished(_view, _url);
			}
		});
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		imageview10 = (ImageView) findViewById(R.id.imageview10);



		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("http://www.seemantaengg.ac.in");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s3 = sound.play((int)(3), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("http://www.bputexam.in/LoginMain.aspx?ReturnUrl=%2f");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s2 = sound.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("http://www.seemantaengg.ac.in/sinfo");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s1 = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("https://www.facebook.com/SEEEMANTA/");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
			}
		});
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("http://bputexam.in/studentsection/resultpublished/studentresult.aspx");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s1 = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("http://www.seemantaengg.ac.in/alumini/alumini.asp");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
			}
		});
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("https://www.youtube.com/playlist?list=PLabARvSPvvNZRbz8L5xBaEE71Hfet78mm&jct=yTuSF088Tls0mWc9QltFsb20bxYC9g");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s6 = sound.play((int)(6), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.loadUrl("https://driveuploader.com/upload/aH0ge63eaq/");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				s4 = sound.play((int)(4), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				showMessage("Developer\nASHWINI KUMAR SINHA\n\n\nFor feedback and query mail @\n@gmail.com\nsinhaashwinkumarsinha@gmail.com\nAshwsinha @gmail.com");
				s5 = sound.play((int)(5), 1.0f, 1.0f, 1, (int)(0), 1.0f);
			}
		});
		imageview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.zoomIn();
			}
		});
		imageview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview1.zoomOut();
			}
		});


		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView _parent, View _view, final int _position, long _id) { 
				if (spinner1.getSelectedItemPosition() == 0) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg. ac.in");
				}
				if (spinner1.getSelectedItemPosition() == 1) {
					webview1.loadUrl("http://www.seemantaengg.ac.in/dinfo/Frm_Login.aspx");
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				}
				if (spinner1.getSelectedItemPosition() == 2) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.calculatoria.com/?lay=0");
				}
				if (spinner1.getSelectedItemPosition() == 3) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.unitconverters.net");
				}
				if (spinner1.getSelectedItemPosition() == 4) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.dictionary.com");
				}
				if (spinner1.getSelectedItemPosition() == 5) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("https://www.resume.com/builder");
				}
				if (spinner1.getSelectedItemPosition() == 6) {
					webview1.loadUrl("https://www.indeed.co.in/m/?gclid=Cj0KCQjwh_bLBRDeARIsAH4ZYEPfHXNxy1LLiS8hBo-pb34mTyhXhe4CVa5CHB7NtyGLtgycDaumQjkaAsGzEALw_wcB");
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				}
				if (spinner1.getSelectedItemPosition() == 7) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("https://www.freshersworld.com/jobs/category/govt-sector-job-vacancies#");
				}
				if (spinner1.getSelectedItemPosition() == 8) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.bput.ac.in/student-notices.php");
				}
				if (spinner1.getSelectedItemPosition() == 9) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg.ac.in/facilities/hostel.asp");
				}
				if (spinner1.getSelectedItemPosition() == 10) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg.ac.in/misc/contact.asp");
				}
				if (spinner1.getSelectedItemPosition() == 11) {
					webview1.loadUrl("http://www.seemantaengg.ac.in/staff/teaching.asp");
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				}
				if (spinner1.getSelectedItemPosition() == 12) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg.ac.in/academic/admission_fees.asp");
				}
				if (spinner1.getSelectedItemPosition() == 13) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg. ac.in/sinfo/degree_syllabus.asp\n");
				}
				if (spinner1.getSelectedItemPosition() == 14) {
					webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
					webview1.loadUrl("http://www.seemantaengg.ac.in/sinfo/attend_report_sem.asp");
				}
			}
			@Override
			public void onNothingSelected(AdapterView _parent) { 
			}
		});

	}

	private void  initializeLogic() {
		webview1.loadUrl("http://www.seemantaengg.ac.in");
		webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		showMessage("Devloper Ashwini kumar");
		sound = new SoundPool((int)(6), AudioManager.STREAM_MUSIC, 0);
		s1 = sound.load(getApplicationContext(), R.raw.logi, 1);
		s2 = sound.load(getApplicationContext(), R.raw.certifica, 1);
		s3 = sound.load(getApplicationContext(), R.raw.inovater, 1);
		s4 = sound.load(getApplicationContext(), R.raw.cloy, 1);
		s5 = sound.load(getApplicationContext(), R.raw.devloped, 1);
		s6 = sound.load(getApplicationContext(), R.raw.beautiful, 1);
		list.add("Home");
		list.add("diploma login");
		list.add("calculater");
		list.add("unit converter");
		list.add("dictionary");
		list.add("Resume maker");
		list.add("job");
		list.add("ijob");
		list.add("Bput notices");
		list.add("seemanta facilities");
		list.add("seemanta contect");
		list.add("seemanta faculty");
		list.add("seemanta fees");
		list.add("syllabus");
		list.add("Attendance");
		list.add("drive");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, list));
	}

	@Override
	public void onStart() {
		super.onStart();
				webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				webview1.loadUrl("http://www.seemantaengg.ac.in");
				showMessage("welcome seemanta app");
				s6 = sound.play((int)(6), 1.0f, 1.0f, 1, (int)(0), 1.0f);
	}
	@Override
	public void onBackPressed() {
				if (webview1.canGoBack()) {
					webview1.goBack();
				}
				else {
					finish();
				}
	}



	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
